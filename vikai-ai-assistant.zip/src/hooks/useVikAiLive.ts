import { useState, useRef, useCallback, useEffect } from 'react';
import { VikAiState, VibeTheme, ToolCallEvent, PersonalityConfig, VikAiAction } from '../types/vikai';
import { AudioStreamer } from '../utils/audioStreamer';

export function useVikAiLive(
  vibe: VibeTheme,
  setVibe: (vibe: VibeTheme) => void,
  personality: PersonalityConfig
) {
  const [state, setState] = useState<VikAiState>('disconnected');
  const [micVolume, setMicVolume] = useState<number>(0);
  const [speakerVolume, setSpeakerVolume] = useState<number>(0);
  const [liveSubtitle, setLiveSubtitle] = useState<string>('');
  const [hasMicPermission, setHasMicPermission] = useState<boolean>(true);
  const [isSpeakerOnlyMode, setIsSpeakerOnlyMode] = useState<boolean>(false);
  const [recentAction, setRecentAction] = useState<VikAiAction | null>(null);
  const [lastInterrupted, setLastInterrupted] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const streamerRef = useRef<AudioStreamer | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const subtitleTimeoutRef = useRef<number | null>(null);

  // Volume analyzer loop
  const startVolumeLoop = useCallback((streamer: AudioStreamer) => {
    const update = () => {
      const inVol = streamer.getInputVolume();
      const outVol = streamer.getOutputVolume();
      setMicVolume(inVol);
      setSpeakerVolume(outVol);
      animFrameRef.current = requestAnimationFrame(update);
    };
    animFrameRef.current = requestAnimationFrame(update);
  }, []);

  const stopVolumeLoop = useCallback(() => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    setMicVolume(0);
    setSpeakerVolume(0);
  }, []);

  // Action executor
  const handleToolCall = useCallback((event: ToolCallEvent) => {
    console.log('[VikAi] Received tool call:', event);
    if (event.name === 'openWebsite') {
      const url = String(event.args.url || '');
      const siteName = String(event.args.name || url);
      if (url) {
        setRecentAction({
          type: 'website',
          title: `Opening ${siteName}`,
          description: url,
        });

        if (personality.autoOpenTabs) {
          try {
            window.open(url, '_blank', 'noopener,noreferrer');
          } catch (e) {
            console.warn('Could not auto-open tab (popup blocked or iframe constraint):', e);
          }
        }
      }
    } else if (event.name === 'changeVibeTheme') {
      const requestedVibe = String(event.args.vibe || '') as VibeTheme;
      if (['neon-violet', 'cyber-cyan', 'electric-magenta', 'sunset-amber', 'emerald-matrix'].includes(requestedVibe)) {
        setVibe(requestedVibe);
        setRecentAction({
          type: 'vibe',
          title: `Vibe Shifted`,
          description: `Changed atmosphere to ${requestedVibe}`,
        });
      }
    } else if (event.name === 'performAction') {
      const actionName = String(event.args.action || '');
      const msg = String(event.args.message || 'VikAi activated a dynamic effect');
      setRecentAction({
        type: 'effect',
        title: `Effect: ${actionName.replace('_', ' ').toUpperCase()}`,
        description: msg,
      });
    }
  }, [personality.autoOpenTabs, setVibe]);

  // Connect & Start Voice Session
  const connect = useCallback(async (allowSpeakerFallback: boolean = true) => {
    if (state !== 'disconnected') return;
    setErrorMessage(null);
    setState('connecting');
    setLiveSubtitle('Connecting to VikAi...');

    try {
      // 1. Initialize streamer and microphone
      const streamer = new AudioStreamer();
      const { hasMic } = await streamer.startRecording(allowSpeakerFallback);
      streamerRef.current = streamer;
      setHasMicPermission(hasMic);
      setIsSpeakerOnlyMode(!hasMic);

      // 2. Open WebSocket to server
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      streamer.onAudioData = (base64Pcm: string) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ audio: base64Pcm }));
        }
      };

      streamer.onSpeakingStateChange = (speaking: boolean) => {
        if (ws.readyState === WebSocket.OPEN) {
          setState(speaking ? 'speaking' : 'listening');
        }
      };

      ws.onopen = () => {
        console.log('[VikAi] WebSocket connected');
        setState('listening');
        setLiveSubtitle(hasMic ? "Listening to your voice..." : "Voice speaker active! Tap quick prompts to chat.");
        startVolumeLoop(streamer);

        // Prompt VikAi to initiate a sassy greeting
        ws.send(JSON.stringify({ trigger_greeting: true }));
      };

      ws.onmessage = async (e) => {
        try {
          const msg = JSON.parse(e.data);

          if (msg.type === 'audio' && msg.audio) {
            await streamer.enqueuePcmAudio(msg.audio);
          } else if (msg.type === 'text_chunk' && msg.text) {
            setLiveSubtitle((prev) => {
              const updated = prev ? `${prev} ${msg.text}` : msg.text;
              return updated.slice(-140);
            });
            if (subtitleTimeoutRef.current) clearTimeout(subtitleTimeoutRef.current);
            subtitleTimeoutRef.current = window.setTimeout(() => {
              // gently fade subtitles after 6s of silence
            }, 6000);
          } else if (msg.type === 'interrupted') {
            streamer.interrupt();
            setState('listening');
            setLastInterrupted(true);
            setTimeout(() => setLastInterrupted(false), 1200);
          } else if (msg.type === 'tool_call') {
            handleToolCall({
              id: msg.id,
              name: msg.name,
              args: msg.args || {},
              timestamp: Date.now(),
            });
          } else if (msg.type === 'error') {
            setErrorMessage(msg.error);
          }
        } catch (err) {
          console.error('[VikAi] Error processing WS packet:', err);
        }
      };

      ws.onerror = (err) => {
        console.error('[VikAi] WebSocket error:', err);
        setErrorMessage('Connection error. Please verify microphone permission and API key.');
      };

      ws.onclose = () => {
        console.log('[VikAi] WebSocket closed');
        disconnect();
      };
    } catch (err: any) {
      console.error('[VikAi] Connection error:', err);
      const isPermError = err?.name === 'NotAllowedError' || String(err?.message || '').toLowerCase().includes('permission');
      if (isPermError) {
        setHasMicPermission(false);
        setErrorMessage('Microphone access was denied. Please allow mic permission in your browser or open the app in a new tab.');
      } else {
        setErrorMessage(err?.message || 'Could not connect to VikAi live session.');
      }
      disconnect();
    }
  }, [state, startVolumeLoop, handleToolCall]);

  // Disconnect & Cleanup
  const disconnect = useCallback(() => {
    stopVolumeLoop();

    if (streamerRef.current) {
      streamerRef.current.stop();
      streamerRef.current = null;
    }

    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {
        // ignore
      }
      wsRef.current = null;
    }

    setState('disconnected');
    setLiveSubtitle('');
  }, [stopVolumeLoop]);

  // Send image frame from screen share or camera
  const sendImageFrame = useCallback((base64Jpeg: string) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          image: base64Jpeg,
          mimeType: 'image/jpeg',
        })
      );
    }
  }, []);

  // Send quick voice simulation or prompt trigger
  const sendPromptTrigger = useCallback((textPrompt: string) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          text_prompt: textPrompt,
        })
      );
      setLiveSubtitle(`You asked: "${textPrompt}"`);
    } else {
      // If not connected, connect first
      connect();
    }
  }, [connect]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      disconnect();
    };
  }, [disconnect]);

  return {
    state,
    micVolume,
    speakerVolume,
    liveSubtitle,
    hasMicPermission,
    isSpeakerOnlyMode,
    recentAction,
    lastInterrupted,
    errorMessage,
    streamer: streamerRef.current,
    connect,
    disconnect,
    sendPromptTrigger,
    sendImageFrame,
    clearRecentAction: () => setRecentAction(null),
    clearError: () => setErrorMessage(null),
  };
}
