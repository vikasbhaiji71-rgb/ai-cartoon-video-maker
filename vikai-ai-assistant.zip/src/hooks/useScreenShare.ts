import { useState, useRef, useCallback, useEffect } from 'react';

interface UseScreenShareOptions {
  onFrame?: (base64Jpeg: string) => void;
  onShareStarted?: () => void;
  onShareEnded?: () => void;
}

export function useScreenShare({
  onFrame,
  onShareStarted,
  onShareEnded,
}: UseScreenShareOptions = {}) {
  const [isScreenSharing, setIsScreenSharing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const streamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const intervalRef = useRef<number | null>(null);

  const stopScreenShare = useCallback(() => {
    // 1. Clear frame capture interval
    if (intervalRef.current !== null) {
      window.clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    // 2. Stop all video tracks
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {
          // ignore
        }
      });
      streamRef.current = null;
    }

    // 3. Clean up hidden video element
    if (videoRef.current) {
      videoRef.current.srcObject = null;
      videoRef.current = null;
    }

    canvasRef.current = null;
    setIsScreenSharing(false);
    setStatusMessage('Screen sharing stopped.');

    if (onShareEnded) {
      onShareEnded();
    }
  }, [onShareEnded]);

  const captureFrame = useCallback(() => {
    const video = videoRef.current;
    if (!video || video.readyState < 2 || !video.videoWidth || !video.videoHeight) {
      return;
    }

    try {
      if (!canvasRef.current) {
        canvasRef.current = document.createElement('canvas');
      }
      const canvas = canvasRef.current;
      
      // Calculate scaled dimensions to preserve bandwidth and latency
      const maxWidth = 960;
      const maxHeight = 540;
      let width = video.videoWidth;
      let height = video.videoHeight;

      if (width > maxWidth || height > maxHeight) {
        const ratio = Math.min(maxWidth / width, maxHeight / height);
        width = Math.round(width * ratio);
        height = Math.round(height * ratio);
      }

      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.drawImage(video, 0, 0, width, height);

      // Export as compact JPEG
      const dataUrl = canvas.toDataURL('image/jpeg', 0.6);
      const base64Data = dataUrl.split(',')[1];

      if (base64Data && onFrame) {
        onFrame(base64Data);
      }
    } catch (err) {
      console.warn('[ScreenShare] Frame capture error:', err);
    }
  }, [onFrame]);

  const startScreenShare = useCallback(async (): Promise<boolean> => {
    setError(null);

    // 1. Check browser support for getDisplayMedia
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      const msg = 'आपके browser में screen share support उपलब्ध नहीं है।';
      setError(msg);
      setStatusMessage(msg);
      return false;
    }

    try {
      // 2. Request native screen capture with explicit user prompt
      const displayMediaOptions: any = {
        video: {
          cursor: 'always',
          frameRate: { ideal: 5, max: 10 },
        },
        audio: false,
      };
      const mediaStream = await (navigator.mediaDevices as any).getDisplayMedia(displayMediaOptions);

      streamRef.current = mediaStream;

      // 3. Create hidden playback element to read frames from stream
      const video = document.createElement('video');
      video.autoplay = true;
      video.muted = true;
      video.playsInline = true;
      video.srcObject = mediaStream;
      videoRef.current = video;

      await video.play().catch(() => {});

      // 4. Listen to native browser "Stop sharing" event
      const videoTrack = mediaStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.onended = () => {
          stopScreenShare();
        };
      }

      setIsScreenSharing(true);
      setStatusMessage('Screen sharing active — VikAI is watching');

      if (onShareStarted) {
        onShareStarted();
      }

      // 5. Initial frame capture after short delay
      setTimeout(() => {
        captureFrame();
      }, 500);

      // 6. Efficient periodic frame grab (every 1.8 seconds)
      if (intervalRef.current !== null) {
        window.clearInterval(intervalRef.current);
      }
      intervalRef.current = window.setInterval(() => {
        captureFrame();
      }, 1800);

      return true;
    } catch (err: any) {
      console.log('[ScreenShare] getDisplayMedia error:', err);
      if (
        err?.name === 'NotAllowedError' ||
        err?.name === 'AbortError' ||
        String(err?.message || '').toLowerCase().includes('cancel') ||
        String(err?.message || '').toLowerCase().includes('permission')
      ) {
        const msg = 'Screen share cancel हो गया। जब चाहें फिर से शुरू कर सकते हैं।';
        setError(msg);
        setStatusMessage(msg);
      } else {
        const msg = 'Screen share शुरू करने में समस्या आई। कृपया फिर कोशिश करें।';
        setError(msg);
        setStatusMessage(msg);
      }
      return false;
    }
  }, [captureFrame, onShareStarted, stopScreenShare]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopScreenShare();
    };
  }, [stopScreenShare]);

  return {
    isScreenSharing,
    error,
    statusMessage,
    startScreenShare,
    stopScreenShare,
    clearError: () => setError(null),
  };
}
