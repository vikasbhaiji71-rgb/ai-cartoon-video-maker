import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, Volume2, ShieldCheck, Flame, Radio, Palette, Lock } from 'lucide-react';
import { PersonalityConfig, VoiceOption, VibeTheme, VibeConfig } from '../types/vikai';
import { VIBE_THEMES } from '../constants/vibes';

interface PersonalitySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  personality: PersonalityConfig;
  setPersonality: React.Dispatch<React.SetStateAction<PersonalityConfig>>;
  currentVibe: VibeTheme;
  setVibe: (v: VibeTheme) => void;
  vibeConfig: VibeConfig;
  onLockApp?: () => void;
}

const VOICES: { id: VoiceOption; name: string; desc: string }[] = [
  { id: 'Aoede', name: 'Aoede', desc: 'Melodic, expressive, highly charismatic & playful' },
  { id: 'Kore', name: 'Kore', desc: 'Warm, dynamic, confident and engaging' },
  { id: 'Zephyr', name: 'Zephyr', desc: 'Calm, crisp, smooth and modern' },
  { id: 'Puck', name: 'Puck', desc: 'High energy, spunky and witty' },
];

export const PersonalitySettingsModal: React.FC<PersonalitySettingsModalProps> = ({
  isOpen,
  onClose,
  personality,
  setPersonality,
  currentVibe,
  setVibe,
  vibeConfig,
  onLockApp,
}) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/70 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-md rounded-3xl bg-neutral-900 border border-white/15 p-6 shadow-2xl z-10 overflow-hidden"
          style={{
            boxShadow: `0 20px 60px rgba(0,0,0,0.8), 0 0 30px ${vibeConfig.glow}`,
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div className="flex items-center space-x-2">
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center text-white"
                style={{
                  background: `linear-gradient(135deg, ${vibeConfig.primary}, ${vibeConfig.accent})`,
                }}
              >
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">VikAI Settings & Vibe</h3>
                <p className="text-xs text-neutral-400">Created by VikasG • Audio & Persona</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="mt-4 space-y-5 max-h-[70vh] overflow-y-auto pr-1">
            {/* Vibe Atmosphere selector */}
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5 mb-2">
                <Palette className="w-3.5 h-3.5 text-pink-400" />
                Vibe Theme
              </label>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                {Object.values(VIBE_THEMES).map((v) => (
                  <button
                    key={v.id}
                    onClick={() => setVibe(v.id)}
                    className={`p-2.5 rounded-xl border text-left transition-all flex items-center space-x-2 ${
                      currentVibe === v.id
                        ? 'border-white bg-white/15 shadow-md'
                        : 'border-white/10 bg-white/5 hover:bg-white/10'
                    }`}
                  >
                    <div
                      className="w-4 h-4 rounded-full shrink-0 shadow-sm"
                      style={{ background: v.primary }}
                    />
                    <span className="text-xs font-medium text-white truncate">{v.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Voice Selection */}
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5 mb-2">
                <Volume2 className="w-3.5 h-3.5 text-purple-400" />
                Voice Tone
              </label>
              <div className="space-y-1.5">
                {VOICES.map((v) => (
                  <button
                    key={v.id}
                    onClick={() => setPersonality((prev) => ({ ...prev, voice: v.id }))}
                    className={`w-full p-3 rounded-xl border text-left transition-all flex items-center justify-between ${
                      personality.voice === v.id
                        ? 'border-purple-400/80 bg-purple-500/15 shadow-sm'
                        : 'border-white/10 bg-white/5 hover:bg-white/10'
                    }`}
                  >
                    <div>
                      <span className="text-xs font-bold text-white block">{v.name}</span>
                      <span className="text-[11px] text-neutral-400">{v.desc}</span>
                    </div>
                    {personality.voice === v.id && (
                      <Radio className="w-4 h-4 text-purple-400 shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Sass Level */}
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5 mb-2">
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                Sass & Banter Level
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['subtle', 'playful', 'unhinged'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setPersonality((prev) => ({ ...prev, sassLevel: lvl }))}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold capitalize transition-all ${
                      personality.sassLevel === lvl
                        ? 'border-pink-500 bg-pink-500/20 text-white'
                        : 'border-white/10 bg-white/5 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>

            {/* Auto-Open Website Actions */}
            <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-white block">Auto-Open Tools & Links</span>
                <span className="text-[11px] text-neutral-400">
                  Instantly open websites when VikAI triggers them
                </span>
              </div>
              <input
                type="checkbox"
                checked={personality.autoOpenTabs}
                onChange={(e) =>
                  setPersonality((prev) => ({ ...prev, autoOpenTabs: e.target.checked }))
                }
                className="w-4 h-4 rounded accent-purple-500 cursor-pointer"
              />
            </div>

            {/* Security & Lock Option */}
            {onLockApp && (
              <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-cyan-200 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-cyan-400" />
                    Lock VikAI Session
                  </span>
                  <span className="text-[11px] text-neutral-400">
                    Disconnect assistant & return to password lock
                  </span>
                </div>
                <button
                  type="button"
                  id="settings-lock-vikai-btn"
                  onClick={() => {
                    onClose();
                    onLockApp();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 hover:text-rose-100 border border-rose-500/40 text-xs font-bold transition-all cursor-pointer shadow"
                >
                  🔒 Lock
                </button>
              </div>
            )}
          </div>

          <div className="mt-6 pt-3 border-t border-white/10 flex items-center justify-between">
            <span className="text-[11px] text-neutral-500 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Gemini Live API Ready
            </span>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white transition-opacity hover:opacity-90 cursor-pointer"
              style={{
                background: `linear-gradient(135deg, ${vibeConfig.primary}, ${vibeConfig.accent})`,
              }}
            >
              Apply Settings
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
