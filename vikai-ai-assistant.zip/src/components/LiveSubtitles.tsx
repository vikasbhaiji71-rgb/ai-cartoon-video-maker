import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, MessageCircleHeart } from 'lucide-react';
import { VibeConfig, VikAiState } from '../types/vikai';

interface LiveSubtitlesProps {
  subtitle: string;
  state: VikAiState;
  vibe: VibeConfig;
}

export const LiveSubtitles: React.FC<LiveSubtitlesProps> = ({ subtitle, state, vibe }) => {
  if (!subtitle && state === 'disconnected') return null;

  return (
    <div id="live-subtitles-container" className="w-full max-w-lg px-4 min-h-[4rem] flex items-center justify-center">
      <AnimatePresence mode="wait">
        {subtitle ? (
          <motion.div
            key={subtitle}
            initial={{ opacity: 0, y: 8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.96 }}
            transition={{ duration: 0.2 }}
            className="w-full px-4 py-2.5 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-xl shadow-xl flex items-start space-x-3"
            style={{
              borderColor: `${vibe.primary}30`,
              boxShadow: `0 8px 32px rgba(0,0,0,0.4), inset 0 0 12px ${vibe.glow}`,
            }}
          >
            <div
              className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5"
              style={{
                background: `linear-gradient(135deg, ${vibe.primary}, ${vibe.accent})`,
              }}
            >
              <MessageCircleHeart className="w-3.5 h-3.5 text-white" />
            </div>

            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-0.5">
                <span className="text-[11px] font-bold tracking-wider uppercase" style={{ color: vibe.accent }}>
                  VikAi
                </span>
                <span className="text-[10px] text-neutral-500">• Live Speech</span>
              </div>
              <p className="text-xs sm:text-sm text-neutral-200 leading-relaxed font-normal italic">
                "{subtitle}"
              </p>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center text-xs text-neutral-500 italic flex items-center gap-1.5"
          >
            <Sparkles className="w-3 h-3 text-neutral-600" />
            <span>Voice-to-voice stream active. Talk directly to VikAi.</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
