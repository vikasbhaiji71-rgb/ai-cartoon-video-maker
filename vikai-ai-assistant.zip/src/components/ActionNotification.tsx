import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, Sparkles, X, Globe, Zap, Palette } from 'lucide-react';
import { VikAiAction, VibeConfig } from '../types/vikai';

interface ActionNotificationProps {
  action: VikAiAction | null;
  vibe: VibeConfig;
  onDismiss: () => void;
}

export const ActionNotification: React.FC<ActionNotificationProps> = ({
  action,
  vibe,
  onDismiss,
}) => {
  if (!action) return null;

  const isLink = action.type === 'website';

  const getIcon = () => {
    switch (action.type) {
      case 'website':
        return Globe;
      case 'vibe':
        return Palette;
      case 'effect':
        return Zap;
      default:
        return Sparkles;
    }
  };

  const IconComponent = getIcon();

  return (
    <AnimatePresence>
      <motion.div
        id="vikai-action-notification"
        initial={{ opacity: 0, y: -20, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -15, scale: 0.9 }}
        className="fixed top-20 left-1/2 -translate-x-1/2 z-50 w-11/12 max-w-md p-3.5 rounded-2xl bg-neutral-900/90 border border-white/15 backdrop-blur-2xl shadow-2xl flex items-center justify-between space-x-3"
        style={{
          boxShadow: `0 10px 40px rgba(0,0,0,0.6), 0 0 20px ${vibe.glow}`,
          borderColor: `${vibe.primary}50`,
        }}
      >
        <div className="flex items-center space-x-3 min-w-0">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
            style={{
              background: `linear-gradient(135deg, ${vibe.primary}, ${vibe.accent})`,
              color: '#ffffff',
            }}
          >
            <IconComponent className="w-5 h-5 animate-pulse" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center space-x-1.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-pink-400">
                Action Triggered
              </span>
            </div>
            <h4 className="text-sm font-semibold text-white truncate">{action.title}</h4>
            <p className="text-xs text-neutral-400 truncate">{action.description}</p>
          </div>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          {isLink && (
            <a
              href={action.description}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-white flex items-center space-x-1.5 transition-colors"
            >
              <span>Visit</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
          <button
            onClick={onDismiss}
            className="p-1.5 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
