import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Volume2, Sparkles, Brain, Radio, Zap } from 'lucide-react';
import { VikAiState, VibeConfig } from '../types/vikai';

interface VikAiLedAvatarProps {
  state: VikAiState;
  vibe: VibeConfig;
  micVolume: number;
  speakerVolume: number;
  isInterrupted: boolean;
  onToggle: () => void;
}

type BlinkType = 'normal' | 'slow' | 'double' | 'happy' | 'thinking';

export const VikAiLedAvatar: React.FC<VikAiLedAvatarProps> = ({
  state,
  vibe,
  micVolume,
  speakerVolume,
  isInterrupted,
  onToggle,
}) => {
  const isConnected = state !== 'disconnected';
  const isListening = state === 'listening';
  const isSpeaking = state === 'speaking';
  const isConnecting = state === 'connecting';
  const isThinking = isConnecting || (isConnected && !isSpeaking && !isListening);

  // ─────────────────────────────────────────────────────────────
  // 1. ORGANIC ADVANCED BLINK SYSTEM (Random intervals & types)
  // ─────────────────────────────────────────────────────────────
  const [blinkState, setBlinkState] = useState<{ isBlinking: boolean; type: BlinkType }>({
    isBlinking: false,
    type: 'normal',
  });

  useEffect(() => {
    let timer: NodeJS.Timeout;
    const scheduleNextBlink = () => {
      // Natural variable duration between blinks (2.4s to 5.2s)
      const delay = Math.random() * 2800 + 2400;
      timer = setTimeout(() => {
        const rand = Math.random();
        let chosenType: BlinkType = 'normal';

        if (isSpeaking && rand > 0.6) {
          chosenType = 'happy';
        } else if (isListening && rand > 0.75) {
          chosenType = 'thinking';
        } else if (rand > 0.82) {
          chosenType = 'double';
        } else if (rand > 0.7) {
          chosenType = 'slow';
        }

        if (chosenType === 'double') {
          setBlinkState({ isBlinking: true, type: 'normal' });
          setTimeout(() => {
            setBlinkState({ isBlinking: false, type: 'normal' });
            setTimeout(() => {
              setBlinkState({ isBlinking: true, type: 'normal' });
              setTimeout(() => {
                setBlinkState({ isBlinking: false, type: 'normal' });
                scheduleNextBlink();
              }, 120);
            }, 80);
          }, 110);
        } else {
          const duration = chosenType === 'slow' ? 300 : 150;
          setBlinkState({ isBlinking: true, type: chosenType });
          setTimeout(() => {
            setBlinkState({ isBlinking: false, type: chosenType });
            scheduleNextBlink();
          }, duration);
        }
      }, delay);
    };

    scheduleNextBlink();
    return () => clearTimeout(timer);
  }, [isSpeaking, isListening]);

  // ─────────────────────────────────────────────────────────────
  // 2. INTELLIGENT GAZE & EYE STATE TRACKING
  // ─────────────────────────────────────────────────────────────
  const [gaze, setGaze] = useState({ x: 0, y: 0, scaleY: 1, tilt: 0 });

  useEffect(() => {
    if (!isConnected) {
      setGaze({ x: 0, y: 0, scaleY: 1, tilt: 0 });
      return;
    }

    const gazeInterval = setInterval(() => {
      if (isSpeaking) {
        // Expressive gaze shifts and cheerful eye movements while speaking
        setGaze({
          x: (Math.random() - 0.5) * 5,
          y: (Math.random() - 0.5) * 4,
          scaleY: 1 + Math.random() * 0.08,
          tilt: (Math.random() - 0.5) * 3,
        });
      } else if (isListening) {
        // Focused attentiveness leaning slightly forward toward user
        setGaze({
          x: (Math.random() - 0.5) * 3,
          y: Math.min(2.5, Math.random() * 3),
          scaleY: 1.05,
          tilt: 0,
        });
      } else if (isThinking) {
        // Subtle contemplative gaze looking slightly up/side
        setGaze({
          x: (Math.random() > 0.5 ? 1 : -1) * 3.5,
          y: -2.5,
          scaleY: 0.95,
          tilt: 2,
        });
      } else {
        // Calm idle micro-glance
        setGaze({
          x: (Math.random() - 0.5) * 3,
          y: (Math.random() - 0.5) * 2,
          scaleY: 1,
          tilt: 0,
        });
      }
    }, 1800);

    return () => clearInterval(gazeInterval);
  }, [isConnected, isSpeaking, isListening, isThinking]);

  // ─────────────────────────────────────────────────────────────
  // 3. AMPLITUDE-DRIVEN LIP-SYNC & MOUTH SHAPES
  // ─────────────────────────────────────────────────────────────
  const mouthOpenness = isSpeaking
    ? Math.min(1, Math.max(0.15, speakerVolume * 2.2))
    : isListening
    ? Math.min(0.35, micVolume * 0.9)
    : 0;

  const mouthWidth = isSpeaking
    ? Math.min(64, 34 + speakerVolume * 42)
    : isListening
    ? 38
    : 32;

  // Floating Micro LED Light Particles inside holographic chamber
  const particles = [
    { id: 1, x: 20, y: 30, s: 2, d: 2.8 },
    { id: 2, x: 78, y: 25, s: 2.5, d: 3.4 },
    { id: 3, x: 15, y: 70, s: 1.5, d: 4.2 },
    { id: 4, x: 84, y: 68, s: 3, d: 2.6 },
    { id: 5, x: 50, y: 18, s: 2, d: 3.1 },
    { id: 6, x: 45, y: 82, s: 1.8, d: 3.7 },
  ];

  // Colors: Cyan / Electric-Blue primary with Subtle Violet Ambient Glow
  const primaryCyan = '#06b6d4';
  const electricBlue = '#38bdf8';
  const ambientViolet = 'rgba(147, 51, 234, 0.4)';

  return (
    <div id="vikai-led-avatar-stage" className="relative flex flex-col items-center justify-center select-none py-1">
      {/* Outer Hologram Chamber & Ambient Violet Bloom */}
      <div className="relative flex items-center justify-center w-76 h-76 sm:w-88 sm:h-88">
        
        {/* Layer 1: Violet Ambient Bloom & Cyan Core Plasma */}
        <motion.div
          animate={{
            scale: isSpeaking ? [1, 1.16, 1] : isListening ? [1, 1.07, 1] : [1, 1.02, 1],
            opacity: isConnected ? [0.45, 0.8, 0.45] : [0.15, 0.25, 0.15],
          }}
          transition={{
            duration: isSpeaking ? 1.3 : isListening ? 2.4 : 4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute inset-0 rounded-full blur-3xl pointer-events-none"
          style={{
            background: `radial-gradient(circle, ${electricBlue} 0%, ${primaryCyan} 35%, #9333ea 70%, transparent 85%)`,
          }}
        />

        {/* Layer 2: Orbiting Cyber Ring with Violet Sparks */}
        {isConnected && (
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: isSpeaking ? 10 : 26, repeat: Infinity, ease: "linear" }}
            className="absolute inset-2 sm:inset-3 rounded-full border border-dashed pointer-events-none opacity-30"
            style={{ borderColor: primaryCyan }}
          />
        )}

        {/* Interruption Shockwave Ripple */}
        {isInterrupted && (
          <motion.div
            initial={{ scale: 0.7, opacity: 1 }}
            animate={{ scale: 1.5, opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0 rounded-full bg-rose-500/40 blur-xl pointer-events-none"
          />
        )}

        {/* ══════════════════════════════════════════════════════════ */}
        {/* CENTRAL FUTURISTIC LED AI VISOR FACE                      */}
        {/* ══════════════════════════════════════════════════════════ */}
        <motion.button
          id="vikai-led-face-button"
          onClick={onToggle}
          disabled={isConnecting}
          whileHover={{ scale: 1.025 }}
          whileTap={{ scale: 0.975 }}
          className={`relative z-20 w-64 h-64 sm:w-72 sm:h-72 rounded-[46px] cursor-pointer flex flex-col items-center justify-between p-5.5 transition-all duration-500 focus:outline-none focus:ring-4 focus:ring-cyan-500/30 shadow-2xl overflow-hidden backdrop-blur-3xl ${
            isConnected
              ? 'bg-gradient-to-b from-[#080d1a]/98 via-[#04060e]/98 to-[#020308]/98 text-white'
              : 'bg-gradient-to-b from-[#0d111d]/90 via-[#070a13]/95 to-[#04050a]/98 text-neutral-400 hover:text-white'
          }`}
          style={{
            border: `2px solid ${isConnected ? primaryCyan : 'rgba(255,255,255,0.12)'}`,
            boxShadow: isConnected
              ? `0 0 35px rgba(6, 182, 212, 0.5), 0 0 60px ${ambientViolet}, inset 0 0 30px rgba(0,0,0,0.9), inset 0 1px 2px rgba(255,255,255,0.3)`
              : '0 20px 45px rgba(0,0,0,0.85), inset 0 1px 1px rgba(255,255,255,0.06)',
          }}
        >
          {/* Glass Specular Curve & Top Visor Reflection */}
          <div
            className="absolute top-0 left-0 right-0 h-28 rounded-t-[44px] pointer-events-none"
            style={{
              background: 'linear-gradient(180deg, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0.02) 60%, transparent 100%)',
            }}
          />

          {/* Micro LED Pixel Array Grid Texture */}
          <div
            className="absolute inset-0 opacity-[0.09] pointer-events-none"
            style={{
              backgroundImage: `radial-gradient(${primaryCyan} 1.2px, transparent 1.2px)`,
              backgroundSize: '13px 13px',
            }}
          />

          {/* Floating Micro Light Particles inside Visor Screen */}
          {isConnected && (
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              {particles.map((p) => (
                <motion.div
                  key={p.id}
                  animate={{
                    y: [0, -12, 0],
                    opacity: isSpeaking ? [0.2, 0.75, 0.2] : [0.1, 0.45, 0.1],
                  }}
                  transition={{
                    duration: p.d,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="absolute rounded-full"
                  style={{
                    left: `${p.x}%`,
                    top: `${p.y}%`,
                    width: `${p.s}px`,
                    height: `${p.s}px`,
                    background: electricBlue,
                    boxShadow: `0 0 6px ${electricBlue}`,
                  }}
                />
              ))}
            </div>
          )}

          {/* Top Visor Telemetry Header */}
          <div className="relative z-10 w-full flex items-center justify-between px-2">
            <div className="flex items-center space-x-1.5">
              <span
                className={`w-2 h-2 rounded-full ${
                  isSpeaking
                    ? 'bg-cyan-400 animate-ping'
                    : isListening
                    ? 'bg-emerald-400 animate-pulse'
                    : isConnecting
                    ? 'bg-amber-400 animate-bounce'
                    : 'bg-neutral-600'
                }`}
              />
              <span className="text-[10px] font-extrabold tracking-widest uppercase text-cyan-300">
                {isConnecting ? 'SYNCING' : isSpeaking ? 'VIKAI SPEAKING' : isListening ? 'LISTENING' : isThinking ? 'THINKING' : 'STANDBY'}
              </span>
            </div>

            {/* Futuristic Signal Frequency Meter */}
            <div className="flex items-center space-x-0.5 text-[10px]">
              {isConnected ? (
                <>
                  <span className="w-1 h-2 rounded-xs bg-cyan-400 animate-pulse" />
                  <span className="w-1 h-3 rounded-xs bg-sky-300 animate-pulse" style={{ animationDelay: '120ms' }} />
                  <span className="w-1 h-2.5 rounded-xs bg-purple-400 animate-pulse" style={{ animationDelay: '240ms' }} />
                </>
              ) : (
                <span className="text-neutral-600 font-mono text-[9px]">OFFLINE</span>
              )}
            </div>
          </div>

          {/* ══════════════════════════════════════════════════════════ */}
          {/* CENTER: TWO EXPRESSIVE GLOWING LED EYES & TALKING MOUTH   */}
          {/* ══════════════════════════════════════════════════════════ */}
          <div className="relative z-10 w-full flex-1 flex flex-col items-center justify-center space-y-6 my-auto">
            
            {/* 1. TWO LUMINOUS EXPRESSIVE LED EYES */}
            <div className="w-full flex items-center justify-center space-x-9 sm:space-x-11">
              
              {/* LEFT EYE */}
              <div className="relative flex items-center justify-center">
                {/* Outer Eye Glow Halo */}
                <div
                  className="absolute inset-0 rounded-full blur-md pointer-events-none transition-opacity duration-300"
                  style={{
                    background: primaryCyan,
                    opacity: isConnected ? (isSpeaking ? 0.9 : 0.6) : 0.1,
                  }}
                />

                {/* Eyelid Capsule Container with Natural Blink Animation */}
                <motion.div
                  animate={{
                    scaleY: blinkState.isBlinking ? 0.06 : gaze.scaleY,
                    scaleX: blinkState.isBlinking ? 1.15 : 1,
                    rotate: gaze.tilt,
                  }}
                  transition={{ duration: blinkState.isBlinking ? 0.07 : 0.2 }}
                  className={`relative w-13 h-15 sm:w-15 sm:h-17 rounded-[22px] flex items-center justify-center overflow-hidden transition-all duration-300 ${
                    isConnected
                      ? 'bg-black/90'
                      : 'bg-neutral-950/90'
                  }`}
                  style={{
                    boxShadow: isConnected
                      ? `0 0 22px rgba(6, 182, 212, 0.8), inset 0 0 14px rgba(6, 182, 212, 0.6)`
                      : 'inset 0 0 8px rgba(255,255,255,0.05)',
                    border: `2px solid ${isConnected ? primaryCyan : 'rgba(255,255,255,0.12)'}`,
                  }}
                >
                  {/* Iris / Pupil with Gaze Tracking */}
                  {isConnected ? (
                    <motion.div
                      animate={{
                        x: gaze.x,
                        y: gaze.y,
                        scale: isSpeaking ? [1, 1.08, 1] : 1,
                      }}
                      transition={{ duration: 0.25 }}
                      className="relative w-8.5 h-10.5 rounded-[16px] flex items-center justify-center"
                      style={{
                        background: `radial-gradient(ellipse at 35% 35%, #ffffff 0%, ${electricBlue} 45%, ${primaryCyan} 90%)`,
                        boxShadow: `0 0 14px ${electricBlue}, inset 0 0 6px #ffffff`,
                      }}
                    >
                      {/* High-Tech Specular Glimmer */}
                      <div className="absolute top-1.5 left-1.5 w-2.5 h-3.5 rounded-full bg-white shadow-sm" />
                      <div className="absolute bottom-2 right-2 w-1.2 h-1.2 rounded-full bg-white/90" />
                    </motion.div>
                  ) : (
                    <div className="w-4 h-4 rounded-full bg-neutral-800" />
                  )}

                  {/* Horizontal Scanning Ray during listening */}
                  {isListening && (
                    <motion.div
                      animate={{ y: [-24, 24] }}
                      transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
                      className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-300 to-transparent pointer-events-none opacity-80"
                    />
                  )}
                </motion.div>
              </div>

              {/* RIGHT EYE */}
              <div className="relative flex items-center justify-center">
                {/* Outer Eye Glow Halo */}
                <div
                  className="absolute inset-0 rounded-full blur-md pointer-events-none transition-opacity duration-300"
                  style={{
                    background: primaryCyan,
                    opacity: isConnected ? (isSpeaking ? 0.9 : 0.6) : 0.1,
                  }}
                />

                {/* Eyelid Capsule Container with Natural Blink */}
                <motion.div
                  animate={{
                    scaleY: blinkState.isBlinking ? 0.06 : gaze.scaleY,
                    scaleX: blinkState.isBlinking ? 1.15 : 1,
                    rotate: -gaze.tilt,
                  }}
                  transition={{ duration: blinkState.isBlinking ? 0.07 : 0.2 }}
                  className={`relative w-13 h-15 sm:w-15 sm:h-17 rounded-[22px] flex items-center justify-center overflow-hidden transition-all duration-300 ${
                    isConnected
                      ? 'bg-black/90'
                      : 'bg-neutral-950/90'
                  }`}
                  style={{
                    boxShadow: isConnected
                      ? `0 0 22px rgba(6, 182, 212, 0.8), inset 0 0 14px rgba(6, 182, 212, 0.6)`
                      : 'inset 0 0 8px rgba(255,255,255,0.05)',
                    border: `2px solid ${isConnected ? primaryCyan : 'rgba(255,255,255,0.12)'}`,
                  }}
                >
                  {/* Iris / Pupil with Gaze Tracking */}
                  {isConnected ? (
                    <motion.div
                      animate={{
                        x: gaze.x,
                        y: gaze.y,
                        scale: isSpeaking ? [1, 1.08, 1] : 1,
                      }}
                      transition={{ duration: 0.25 }}
                      className="relative w-8.5 h-10.5 rounded-[16px] flex items-center justify-center"
                      style={{
                        background: `radial-gradient(ellipse at 35% 35%, #ffffff 0%, ${electricBlue} 45%, ${primaryCyan} 90%)`,
                        boxShadow: `0 0 14px ${electricBlue}, inset 0 0 6px #ffffff`,
                      }}
                    >
                      {/* High-Tech Specular Glimmer */}
                      <div className="absolute top-1.5 left-1.5 w-2.5 h-3.5 rounded-full bg-white shadow-sm" />
                      <div className="absolute bottom-2 right-2 w-1.2 h-1.2 rounded-full bg-white/90" />
                    </motion.div>
                  ) : (
                    <div className="w-4 h-4 rounded-full bg-neutral-800" />
                  )}

                  {/* Horizontal Scanning Ray during listening */}
                  {isListening && (
                    <motion.div
                      animate={{ y: [-24, 24] }}
                      transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
                      className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-300 to-transparent pointer-events-none opacity-80"
                    />
                  )}
                </motion.div>
              </div>

            </div>

            {/* 2. AMPLITUDE-DRIVEN TALKING MOUTH / VISEME SYSTEM */}
            <div className="w-full flex items-center justify-center h-10 relative">
              {isSpeaking ? (
                /* Dynamic Viseme Lip Aperture driven by audio output */
                <motion.div
                  animate={{
                    width: mouthWidth,
                    height: Math.max(8, Math.min(30, mouthOpenness * 32)),
                  }}
                  transition={{ duration: 0.07 }}
                  className="rounded-full flex items-center justify-center overflow-hidden relative shadow-lg"
                  style={{
                    background: `linear-gradient(135deg, ${primaryCyan}, ${electricBlue})`,
                    boxShadow: `0 0 16px ${electricBlue}, inset 0 0 8px #ffffff`,
                    border: '1.5px solid rgba(255,255,255,0.85)',
                  }}
                >
                  {/* Subtle Inner Sound Pulse Bars inside mouth aperture */}
                  <div className="flex items-center space-x-1 opacity-90">
                    <span className="w-1 h-3 bg-white rounded-full animate-pulse" />
                    <span className="w-1 h-5 bg-white rounded-full animate-pulse" />
                    <span className="w-1 h-3 bg-white rounded-full animate-pulse" />
                  </div>
                </motion.div>
              ) : isListening ? (
                /* Gentle Attentive Listening Pulse Wave */
                <div className="flex items-center space-x-1.5">
                  <motion.div
                    animate={{ scaleY: [1, 2.8, 1], opacity: [0.5, 1, 0.5] }}
                    transition={{ repeat: Infinity, duration: 1.1, ease: "easeInOut" }}
                    className="w-1.5 h-3 rounded-full"
                    style={{ background: primaryCyan }}
                  />
                  <motion.div
                    animate={{ scaleY: [1, 4, 1], opacity: [0.8, 1, 0.8] }}
                    transition={{ repeat: Infinity, duration: 1.1, delay: 0.2, ease: "easeInOut" }}
                    className="w-1.5 h-4 rounded-full"
                    style={{ background: electricBlue }}
                  />
                  <motion.div
                    animate={{ scaleY: [1, 2.8, 1], opacity: [0.5, 1, 0.5] }}
                    transition={{ repeat: Infinity, duration: 1.1, delay: 0.4, ease: "easeInOut" }}
                    className="w-1.5 h-3 rounded-full"
                    style={{ background: primaryCyan }}
                  />
                </div>
              ) : isConnecting ? (
                /* Connecting Scanning Pulse */
                <motion.div
                  animate={{ scaleX: [0.4, 1.15, 0.4], opacity: [0.3, 1, 0.3] }}
                  transition={{ repeat: Infinity, duration: 1.2, ease: "easeInOut" }}
                  className="w-20 h-1.5 rounded-full"
                  style={{
                    background: `linear-gradient(90deg, transparent, ${primaryCyan}, #ffffff, ${electricBlue}, transparent)`,
                    boxShadow: `0 0 10px ${primaryCyan}`,
                  }}
                />
              ) : (
                /* Standby Friendly Subtle Curved Smile Line */
                <div className="flex flex-col items-center justify-center">
                  <div
                    className="w-12 h-1.5 rounded-full bg-neutral-700/80 border border-neutral-600/50"
                  />
                </div>
              )}
            </div>

          </div>

          {/* Visor Bottom Action Ribbon */}
          <div className="relative z-10 w-full pt-2 pb-0.5 border-t border-white/[0.07] flex items-center justify-center">
            {isConnected ? (
              <div className="flex items-center space-x-1.5 text-xs font-bold text-cyan-300">
                {isSpeaking ? (
                  <>
                    <Volume2 className="w-3.5 h-3.5 animate-bounce text-cyan-400" />
                    <span>VIKAI SPEAKING</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                    <span className="text-neutral-200">LISTENING TO YOU</span>
                  </>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-1.5 text-xs font-semibold text-neutral-400 group-hover:text-white transition-colors">
                <MicOff className="w-3.5 h-3.5 text-neutral-500" />
                <span>TAP TO ACTIVATE VIKAI</span>
              </div>
            )}
          </div>

        </motion.button>
      </div>

      {/* Dynamic Status Capsule Under Avatar */}
      <div className="mt-2.5 flex items-center space-x-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
        <span
          className={`w-2 h-2 rounded-full ${
            isSpeaking
              ? 'bg-cyan-400 animate-ping'
              : isListening
              ? 'bg-emerald-400 animate-pulse'
              : isConnecting
              ? 'bg-amber-400 animate-bounce'
              : 'bg-neutral-500'
          }`}
        />
        <span className="text-xs font-medium text-neutral-300">
          {isSpeaking
            ? 'VikAI is speaking with live audio'
            : isListening
            ? 'VikAI is listening attentively'
            : isConnecting
            ? 'Initializing Gemini Live session...'
            : 'Tap VikAI to start voice conversation'}
        </span>
      </div>
    </div>
  );
};
