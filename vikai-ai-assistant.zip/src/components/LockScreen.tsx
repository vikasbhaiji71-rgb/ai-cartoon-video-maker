import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lock, Unlock, Eye, EyeOff, ShieldAlert, Sparkles, CheckCircle2, KeyRound } from 'lucide-react';
import { VibeConfig } from '../types/vikai';

interface LockScreenProps {
  onUnlock: () => void;
  vibe: VibeConfig;
}

export const LockScreen: React.FC<LockScreenProps> = ({ onUnlock, vibe }) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Auto-focus input for convenience on desktop/mobile
    const timer = setTimeout(() => {
      inputRef.current?.focus();
    }, 400);
    return () => clearTimeout(timer);
  }, []);

  const handleUnlockAttempt = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    if (!password) {
      setError('INCORRECT PASSWORD');
      triggerShake();
      return;
    }

    // Exact case-sensitive password check
    if (password === 'VikAi Chw') {
      setError(null);
      setIsSuccess(true);
      
      // Short dramatic futuristic unlock sequence before launching main UI
      setTimeout(() => {
        onUnlock();
      }, 1100);
    } else {
      setError('INCORRECT PASSWORD');
      triggerShake();
    }
  };

  const triggerShake = () => {
    setIsShaking(true);
    setTimeout(() => {
      setIsShaking(false);
    }, 600);
  };

  return (
    <div
      id="vikai-lockscreen"
      className="fixed inset-0 z-50 flex flex-col items-center justify-between p-4 sm:p-6 bg-[#040711] text-white select-none overflow-hidden font-sans"
    >
      {/* Background Animated Ambient LED Glows */}
      <div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[30rem] sm:w-[42rem] h-[30rem] sm:h-[42rem] rounded-full blur-[140px] pointer-events-none opacity-30 transition-all duration-1000"
        style={{
          background: isSuccess
            ? '#10b981'
            : vibe.primary,
        }}
      />
      <div
        className="absolute bottom-10 right-1/4 w-80 h-80 rounded-full blur-[120px] pointer-events-none opacity-20"
        style={{ background: isSuccess ? '#06b6d4' : '#8b5cf6' }}
      />

      {/* Cyber Grid Background lines */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#06b6d408_1px,transparent_1px),linear-gradient(to_bottom,#06b6d408_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none" />

      {/* Top Header Branding */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10 pt-4 flex flex-col items-center text-center"
      >
        <div className="flex items-center space-x-2.5 mb-1.5">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center border border-cyan-400/40 shadow-lg"
            style={{
              background: `linear-gradient(135deg, ${vibe.primary}, ${vibe.accent})`,
              boxShadow: `0 0 20px rgba(6, 182, 212, 0.4)`,
            }}
          >
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="text-2xl font-black tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-white via-cyan-100 to-cyan-400">
            VIKAI
          </span>
          <span className="text-[10px] font-mono font-extrabold uppercase px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
            v2.4
          </span>
        </div>

        <div className="flex items-center space-x-1.5 text-xs font-bold tracking-widest text-cyan-400/90 uppercase">
          <Lock className="w-3.5 h-3.5 text-cyan-400" />
          <span>SECURE ACCESS</span>
        </div>
      </motion.header>

      {/* Center Holographic LED Face & Futuristic Auth Box */}
      <main className="relative z-10 w-full max-w-md my-auto flex flex-col items-center text-center">
        {/* Glowing VikAI LED Avatar Face in Locked Mode */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="relative mb-6 flex flex-col items-center"
        >
          {/* Outer Cybernetic Ring */}
          <div
            className="relative w-36 h-36 sm:w-40 sm:h-40 rounded-full flex items-center justify-center backdrop-blur-2xl transition-all duration-700"
            style={{
              background: 'radial-gradient(circle, rgba(9,13,26,0.95) 0%, rgba(4,7,17,0.98) 100%)',
              border: `2px solid ${isSuccess ? 'rgba(16,185,129,0.7)' : 'rgba(6,182,212,0.4)'}`,
              boxShadow: isSuccess
                ? '0 0 45px rgba(16, 185, 129, 0.5), inset 0 0 25px rgba(16, 185, 129, 0.3)'
                : '0 0 35px rgba(6, 182, 212, 0.3), inset 0 0 20px rgba(6, 182, 212, 0.15)',
            }}
          >
            {/* Ambient Eye Ring Scan */}
            <div
              className={`absolute inset-1 rounded-full border border-dashed pointer-events-none transition-colors duration-500 ${
                isSuccess ? 'border-emerald-400/50 animate-spin' : 'border-cyan-500/30 animate-[spin_12s_linear_infinite]'
              }`}
            />

            {/* Futuristic Glowing Eyes */}
            <div className="flex items-center space-x-6 sm:space-x-7 z-10">
              {/* Left Eye */}
              <motion.div
                animate={
                  isSuccess
                    ? { scale: [1, 1.3, 1.1], opacity: 1 }
                    : { opacity: [0.7, 1, 0.7], scaleY: [1, 0.9, 1] }
                }
                transition={{
                  repeat: isSuccess ? 0 : Infinity,
                  duration: isSuccess ? 0.6 : 3.2,
                  ease: 'easeInOut',
                }}
                className={`w-6 h-6 sm:w-7 sm:h-7 rounded-xl flex items-center justify-center transition-colors duration-500 ${
                  isSuccess
                    ? 'bg-emerald-400 shadow-[0_0_20px_#10b981]'
                    : 'bg-cyan-400 shadow-[0_0_16px_rgba(6,182,212,0.8)]'
                }`}
              >
                <div className="w-2 h-2 rounded-full bg-white" />
              </motion.div>

              {/* Right Eye */}
              <motion.div
                animate={
                  isSuccess
                    ? { scale: [1, 1.3, 1.1], opacity: 1 }
                    : { opacity: [0.7, 1, 0.7], scaleY: [1, 0.9, 1] }
                }
                transition={{
                  repeat: isSuccess ? 0 : Infinity,
                  duration: isSuccess ? 0.6 : 3.2,
                  ease: 'easeInOut',
                  delay: 0.1,
                }}
                className={`w-6 h-6 sm:w-7 sm:h-7 rounded-xl flex items-center justify-center transition-colors duration-500 ${
                  isSuccess
                    ? 'bg-emerald-400 shadow-[0_0_20px_#10b981]'
                    : 'bg-cyan-400 shadow-[0_0_16px_rgba(6,182,212,0.8)]'
                }`}
              >
                <div className="w-2 h-2 rounded-full bg-white" />
              </motion.div>
            </div>

            {/* Subtle mouth slit in avatar */}
            <div
              className={`absolute bottom-8 w-8 h-1 rounded-full transition-all duration-500 ${
                isSuccess
                  ? 'bg-emerald-400 shadow-[0_0_10px_#10b981] w-12'
                  : 'bg-cyan-400/60 shadow-[0_0_8px_rgba(6,182,212,0.5)]'
              }`}
            />
          </div>

          {/* System Locked Badge */}
          <div className="mt-3.5 flex items-center space-x-1.5 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-500/30 text-[11px] font-mono tracking-wider">
            {isSuccess ? (
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                SYSTEM UNLOCKED
              </span>
            ) : (
              <span className="text-cyan-300/90 font-medium flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                VIKAI SYSTEM LOCKED
              </span>
            )}
          </div>
        </motion.div>

        {/* Futuristic Glass Container for Form */}
        <motion.div
          animate={isShaking ? { x: [-12, 12, -9, 9, -5, 5, 0] } : {}}
          transition={{ duration: 0.5 }}
          className="w-full p-5 sm:p-6 rounded-3xl bg-[#090d1a]/85 border border-cyan-500/30 backdrop-blur-2xl shadow-2xl relative overflow-hidden"
          style={{
            boxShadow: isSuccess
              ? '0 0 40px rgba(16, 185, 129, 0.35), 0 20px 40px rgba(0, 0, 0, 0.9)'
              : '0 0 35px rgba(6, 182, 212, 0.25), 0 20px 40px rgba(0, 0, 0, 0.9), inset 0 1px 1px rgba(255, 255, 255, 0.1)',
          }}
        >
          {/* Subtitle prompt */}
          <p className="text-xs sm:text-sm font-medium text-neutral-300 mb-4">
            Enter password to activate VikAI
          </p>

          <form onSubmit={handleUnlockAttempt} className="space-y-3.5">
            {/* Password Input with show/hide button */}
            <div className="relative flex items-center">
              <div className="absolute left-3.5 text-cyan-400/80 pointer-events-none">
                <KeyRound className="w-4 h-4" />
              </div>

              <input
                ref={inputRef}
                id="vikai-password-input"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (error) setError(null);
                }}
                disabled={isSuccess}
                placeholder="Enter password..."
                autoComplete="current-password"
                className={`w-full pl-10 pr-11 py-3 rounded-2xl bg-black/50 border text-sm font-medium text-white placeholder-neutral-500 focus:outline-none transition-all ${
                  error
                    ? 'border-rose-500 focus:border-rose-400 focus:ring-2 focus:ring-rose-500/30'
                    : isSuccess
                    ? 'border-emerald-400 focus:border-emerald-300'
                    : 'border-cyan-500/30 hover:border-cyan-400/60 focus:border-cyan-400 focus:ring-2 focus:ring-cyan-500/30'
                }`}
              />

              {/* Show / Hide Toggle Button */}
              <button
                type="button"
                id="toggle-password-visibility-btn"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 p-1.5 rounded-xl text-neutral-400 hover:text-cyan-300 transition-colors focus:outline-none cursor-pointer"
                title={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Error Message Display */}
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  className="flex items-center justify-center space-x-1.5 py-1.5 px-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs font-bold tracking-wide"
                >
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                  <span>{error}</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Success Message Display */}
            <AnimatePresence>
              {isSuccess && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex items-center justify-center space-x-1.5 py-1.5 px-3 rounded-xl bg-emerald-950/70 border border-emerald-400/50 text-emerald-300 text-xs font-extrabold tracking-wider animate-pulse"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>ACCESS GRANTED</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Unlock VikAI Action Button */}
            <motion.button
              type="submit"
              id="unlock-vikai-submit-button"
              disabled={isSuccess}
              whileHover={{ scale: isSuccess ? 1 : 1.02 }}
              whileTap={{ scale: isSuccess ? 1 : 0.98 }}
              className={`w-full py-3.5 px-4 rounded-2xl font-bold text-sm tracking-wider uppercase transition-all duration-300 flex items-center justify-center space-x-2 cursor-pointer shadow-lg ${
                isSuccess
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-[0_0_25px_rgba(16,185,129,0.5)]'
                  : 'bg-gradient-to-r from-cyan-500 via-cyan-600 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-[0_0_20px_rgba(6,182,212,0.4)]'
              }`}
            >
              {isSuccess ? (
                <>
                  <Unlock className="w-4 h-4 stroke-[2.5]" />
                  <span>ACCESS GRANTED</span>
                </>
              ) : (
                <>
                  <Unlock className="w-4 h-4 stroke-[2.5]" />
                  <span>UNLOCK VIKAI</span>
                </>
              )}
            </motion.button>
          </form>
        </motion.div>
      </main>

      {/* Footer Tag */}
      <footer className="relative z-10 pb-3 text-center">
        <p className="text-[11px] text-neutral-500 font-mono">
          VikAI Personal Assistant • Created by VikasG
        </p>
      </footer>
    </div>
  );
};
