import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Monitor, Square, Sparkles, Eye } from 'lucide-react';
import { VibeConfig } from '../types/vikai';

interface FloatingScreenShareBarProps {
  isSharing: boolean;
  onStop: () => void;
  vibe: VibeConfig;
}

export const FloatingScreenShareBar: React.FC<FloatingScreenShareBarProps> = ({
  isSharing,
  onStop,
  vibe,
}) => {
  return (
    <AnimatePresence>
      {isSharing && (
        <motion.div
          id="vikai-screen-share-overlay"
          initial={{ opacity: 0, y: -24, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.9 }}
          transition={{ type: 'spring', stiffness: 350, damping: 25 }}
          className="fixed top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-4 py-2.5 rounded-full bg-[#080d1a]/95 border border-cyan-400/40 backdrop-blur-2xl shadow-2xl"
          style={{
            boxShadow: `0 0 25px rgba(6, 182, 212, 0.35), 0 10px 30px rgba(0,0,0,0.85), inset 0 1px 1px rgba(255,255,255,0.2)`,
          }}
        >
          {/* Animated Glowing Monitor Icon */}
          <div className="relative flex items-center justify-center">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center bg-cyan-950 text-cyan-300 border border-cyan-400/40"
              style={{
                boxShadow: `0 0 12px ${vibe.primary}66`,
              }}
            >
              <Monitor className="w-4 h-4 animate-pulse text-cyan-300" />
            </div>
            <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400" />
          </div>

          {/* Status Labels */}
          <div className="flex flex-col pr-1">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-black uppercase tracking-wider text-cyan-300 flex items-center gap-1">
                🖥 SCREEN SHARING
              </span>
              <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-200 border border-cyan-500/30">
                LIVE
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400">
              <Eye className="w-3 h-3 text-emerald-400 animate-pulse" />
              <span>● VIKAI IS WATCHING</span>
            </div>
          </div>

          {/* Stop Screen Share Button */}
          <motion.button
            id="stop-screen-share-btn"
            onClick={onStop}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 hover:text-rose-100 border border-rose-500/40 text-xs font-bold transition-all cursor-pointer shadow-lg"
            title="Stop Screen Share"
          >
            <Square className="w-3 h-3 fill-rose-400 text-rose-400" />
            <span className="whitespace-nowrap">Stop Sharing</span>
          </motion.button>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
