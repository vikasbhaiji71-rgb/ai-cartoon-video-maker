import React from 'react';
import { motion } from 'motion/react';
import { Monitor, Sparkles, UserCheck, Compass, Youtube, HelpCircle } from 'lucide-react';
import { VibeConfig } from '../types/vikai';

interface SassyQuickPromptsProps {
  vibe: VibeConfig;
  onSelectPrompt: (prompt: string) => void;
  disabled?: boolean;
}

const PROMPTS = [
  { text: "तुम्हें किसने बनाया?", icon: UserCheck, tag: "Creator" },
  { text: "Who created you?", icon: Sparkles, tag: "Identity" },
  { text: "मेरी screen देखो और बताओ", icon: Monitor, tag: "Screen" },
  { text: "अपना परिचय दो", icon: HelpCircle, tag: "Intro" },
  { text: "Open YouTube", icon: Youtube, tag: "Tool" },
  { text: "Change vibe to Cyber Cyan", icon: Compass, tag: "Vibe" },
];

export const SassyQuickPrompts: React.FC<SassyQuickPromptsProps> = ({
  vibe,
  onSelectPrompt,
  disabled,
}) => {
  return (
    <div id="sassy-quick-prompts" className="w-full max-w-lg px-4 py-2">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          Talk or Tap to Ask VikAI
        </span>
        <span className="text-[11px] text-neutral-500">Live Voice API</span>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {PROMPTS.map((p, idx) => {
          const Icon = p.icon;
          return (
            <motion.button
              key={idx}
              whileHover={{ scale: 1.02, y: -1 }}
              whileTap={{ scale: 0.98 }}
              disabled={disabled}
              onClick={() => onSelectPrompt(p.text)}
              className="flex items-center space-x-2 p-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.07] hover:border-white/20 transition-all text-left group cursor-pointer focus:outline-none"
            >
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                style={{
                  background: `${vibe.primary}18`,
                  color: vibe.primary,
                }}
              >
                <Icon className="w-4 h-4 group-hover:scale-110 transition-transform" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-neutral-200 truncate group-hover:text-white">
                  {p.text}
                </p>
                <span className="text-[10px] text-neutral-500 group-hover:text-neutral-400">
                  {p.tag}
                </span>
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
};
