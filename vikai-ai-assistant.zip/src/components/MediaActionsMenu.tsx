import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Camera, Image as ImageIcon, FolderUp, Monitor, Plus, X, Sparkles, CheckCircle2 } from 'lucide-react';
import { VibeConfig } from '../types/vikai';

interface MediaActionsMenuProps {
  isOpen: boolean;
  onToggle: () => void;
  vibe: VibeConfig;
  isScreenSharing?: boolean;
  onToggleScreenShare?: () => void;
  onSelectOption?: (optionId: string) => void;
}

export const MediaActionsMenu: React.FC<MediaActionsMenuProps> = ({
  isOpen,
  onToggle,
  vibe,
  isScreenSharing = false,
  onToggleScreenShare,
  onSelectOption,
}) => {
  const menuItems = [
    {
      id: 'live-camera',
      icon: Camera,
      emoji: '📷',
      title: 'Live Camera',
      subtitle: 'Talk with VikAI using camera',
      badge: 'Vision',
    },
    {
      id: 'upload-photo',
      icon: ImageIcon,
      emoji: '🖼',
      title: 'Upload Photo',
      subtitle: 'Ask VikAI about an image',
      badge: 'Image',
    },
    {
      id: 'upload-file',
      icon: FolderUp,
      emoji: '📁',
      title: 'Upload File',
      subtitle: 'Ask VikAI about a file',
      badge: 'File',
    },
    {
      id: 'screen-share',
      icon: Monitor,
      emoji: '🖥',
      title: 'Screen Share',
      subtitle: 'Let VikAI see your screen',
      badge: isScreenSharing ? 'Active' : 'Live',
      isActive: isScreenSharing,
    },
  ];

  const handleAction = (id: string) => {
    if (id === 'screen-share') {
      if (onToggleScreenShare) {
        onToggleScreenShare();
      }
      onToggle(); // Close menu after starting
      return;
    }

    if (onSelectOption) {
      onSelectOption(id);
    }
  };

  return (
    <div className="relative flex flex-col items-center z-30">
      {/* Floating Glassmorphic Menu Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="vikai-media-menu-panel"
            initial={{ opacity: 0, y: 18, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 14, scale: 0.94 }}
            transition={{ type: 'spring', damping: 24, stiffness: 320 }}
            className="absolute bottom-16 mb-2 w-72 sm:w-80 p-3.5 rounded-3xl bg-[#090d1a]/90 border border-cyan-500/30 backdrop-blur-2xl shadow-2xl overflow-hidden"
            style={{
              boxShadow: `0 0 30px rgba(6, 182, 212, 0.25), 0 20px 40px rgba(0, 0, 0, 0.85), inset 0 1px 1px rgba(255, 255, 255, 0.15)`,
            }}
          >
            {/* Ambient Background Glow inside panel */}
            <div
              className="absolute -top-10 -right-10 w-32 h-32 rounded-full blur-2xl pointer-events-none opacity-40"
              style={{ background: vibe.primary }}
            />
            <div
              className="absolute -bottom-10 -left-10 w-32 h-32 rounded-full blur-2xl pointer-events-none opacity-25"
              style={{ background: '#9333ea' }}
            />

            {/* Menu Header */}
            <div className="flex items-center justify-between px-2 pb-2.5 mb-1.5 border-b border-white/[0.08] relative z-10">
              <div className="flex items-center space-x-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-neutral-300">
                  Multimodal & Vision
                </span>
              </div>
              <span className="text-[10px] font-mono text-cyan-400/80 bg-cyan-950/60 px-2 py-0.5 rounded-full border border-cyan-500/20">
                VIKAI LIVE
              </span>
            </div>

            {/* 4 Menu Options */}
            <div className="flex flex-col space-y-1.5 relative z-10">
              {menuItems.map((item, index) => {
                const Icon = item.icon;
                const isSelected = item.isActive;

                return (
                  <motion.button
                    key={item.id}
                    id={`media-action-${item.id}`}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.04 + 0.03 }}
                    whileHover={{ scale: 1.02, x: 2 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleAction(item.id)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-2xl transition-all text-left group cursor-pointer border ${
                      isSelected
                        ? 'bg-cyan-500/20 border-cyan-400/60 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
                        : 'bg-white/[0.03] hover:bg-cyan-500/[0.12] border-white/[0.06] hover:border-cyan-400/40'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      {/* Icon Capsule with LED glow */}
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center border transition-all shrink-0 ${
                          isSelected
                            ? 'bg-cyan-500/30 text-cyan-200 border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.6)]'
                            : 'bg-cyan-950/80 text-cyan-300 border-cyan-400/30 group-hover:border-cyan-400 group-hover:shadow-[0_0_12px_rgba(6,182,212,0.5)]'
                        }`}
                      >
                        <Icon className="w-4 h-4 group-hover:scale-110 transition-transform text-cyan-300" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-1.5">
                          <span className="text-sm">{item.emoji}</span>
                          <span className="text-xs font-bold text-white group-hover:text-cyan-200 transition-colors">
                            {item.title}
                          </span>
                        </div>
                        <span className="text-[10px] text-neutral-400 block group-hover:text-neutral-300">
                          {item.subtitle}
                        </span>
                      </div>
                    </div>

                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-md transition-colors ${
                        isSelected
                          ? 'bg-cyan-400 text-neutral-950 font-bold'
                          : 'text-neutral-500 group-hover:text-cyan-300 bg-white/[0.04] group-hover:bg-cyan-500/20'
                      }`}
                    >
                      {item.badge}
                    </span>
                  </motion.button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating "+" Toggle Button */}
      <motion.button
        id="vikai-media-plus-button"
        onClick={onToggle}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.92 }}
        className={`relative w-12 h-12 rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-cyan-500/30 shadow-xl ${
          isOpen
            ? 'bg-gradient-to-tr from-cyan-500 to-rose-500 text-white'
            : isScreenSharing
            ? 'bg-gradient-to-tr from-cyan-600 via-emerald-600 to-cyan-500 text-white'
            : 'bg-gradient-to-tr from-slate-900 via-cyan-950 to-slate-900 text-cyan-300 hover:text-white'
        }`}
        style={{
          border: `2px solid ${
            isOpen
              ? '#f43f5e'
              : isScreenSharing
              ? '#10b981'
              : 'rgba(6, 182, 212, 0.6)'
          }`,
          boxShadow: isOpen
            ? '0 0 25px rgba(244, 63, 94, 0.6), inset 0 0 10px rgba(255, 255, 255, 0.2)'
            : isScreenSharing
            ? '0 0 25px rgba(16, 185, 129, 0.6), inset 0 0 10px rgba(255, 255, 255, 0.2)'
            : '0 0 20px rgba(6, 182, 212, 0.4), inset 0 0 10px rgba(6, 182, 212, 0.2)',
        }}
        title={isOpen ? 'Close Menu' : isScreenSharing ? 'Screen Sharing Active' : 'Open Media & Screen Share'}
      >
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.25, ease: 'easeInOut' }}
          className="flex items-center justify-center"
        >
          {isOpen ? (
            <X className="w-5 h-5 stroke-[2.5]" />
          ) : (
            <Plus className="w-5 h-5 stroke-[2.5]" />
          )}
        </motion.div>

        {/* Ambient Ring Pulse when closed */}
        {!isOpen && (
          <span
            className={`absolute -inset-0.5 rounded-full border pointer-events-none opacity-40 ${
              isScreenSharing
                ? 'border-emerald-400 animate-ping'
                : 'border-cyan-400/40 animate-ping'
            }`}
          />
        )}
      </motion.button>
    </div>
  );
};
