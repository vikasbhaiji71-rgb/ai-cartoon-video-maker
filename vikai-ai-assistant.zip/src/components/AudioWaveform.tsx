import React, { useRef, useEffect } from 'react';
import { AudioStreamer } from '../utils/audioStreamer';
import { VibeConfig, VikAiState } from '../types/vikai';

interface AudioWaveformProps {
  streamer: AudioStreamer | null;
  state: VikAiState;
  vibe: VibeConfig;
}

export const AudioWaveform: React.FC<AudioWaveformProps> = ({ streamer, state, vibe }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let phase = 0;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const isConnected = state !== 'disconnected';
      const isSpeaking = state === 'speaking';
      const isListening = state === 'listening';

      // Get frequency data from active stream
      let freqData: Uint8Array = new Uint8Array(64);
      if (streamer && isConnected) {
        freqData = streamer.getFrequencyData(isSpeaking);
      }

      // Calculate average intensity
      let sum = 0;
      for (let i = 0; i < freqData.length; i++) {
        sum += freqData[i];
      }
      const rawAvg = sum / freqData.length;
      const intensity = isConnected ? Math.max(0.1, rawAvg / 180) : 0.05;

      phase += isSpeaking ? 0.08 : 0.03;

      // Draw multi-layered glowing sine waves
      const lines = [
        { color: vibe.primary, alpha: 0.8, amp: 28 * intensity, freq: 0.02, speed: 1 },
        { color: vibe.accent, alpha: 0.6, amp: 20 * intensity, freq: 0.03, speed: -1.2 },
        { color: '#ffffff', alpha: 0.4, amp: 14 * intensity, freq: 0.04, speed: 0.8 },
      ];

      lines.forEach((line) => {
        ctx.beginPath();
        ctx.strokeStyle = line.color;
        ctx.globalAlpha = isConnected ? line.alpha : 0.15;
        ctx.lineWidth = isSpeaking ? 2.5 : 1.5;
        ctx.shadowBlur = isConnected ? 12 : 0;
        ctx.shadowColor = line.color;

        const centerY = height / 2;

        for (let x = 0; x < width; x += 3) {
          // Windowing envelope so ends taper off
          const envelope = Math.sin((x / width) * Math.PI);
          const y =
            centerY +
            Math.sin(x * line.freq + phase * line.speed) * line.amp * envelope +
            Math.cos(x * line.freq * 0.5 + phase) * (line.amp * 0.4) * envelope;

          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      });

      animFrameIdRef.current = requestAnimationFrame(render);
    };

    animFrameIdRef.current = requestAnimationFrame(render);

    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, [streamer, state, vibe]);

  return (
    <div id="audio-waveform-canvas-wrap" className="w-full max-w-md h-16 relative flex items-center justify-center my-2">
      <canvas
        ref={canvasRef}
        width={360}
        height={64}
        className="w-full h-full"
      />
    </div>
  );
};
