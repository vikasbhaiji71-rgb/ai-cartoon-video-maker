export type VikAiState = 'disconnected' | 'connecting' | 'listening' | 'speaking';

export type VibeTheme = 'neon-violet' | 'cyber-cyan' | 'electric-magenta' | 'sunset-amber' | 'emerald-matrix';

export interface VibeConfig {
  id: VibeTheme;
  name: string;
  primary: string;
  glow: string;
  bgGradient: string;
  orbGradient: string;
  accent: string;
}

export type VoiceOption = 'Aoede' | 'Kore' | 'Zephyr' | 'Puck' | 'Fenrir' | 'Charon';

export interface PersonalityConfig {
  voice: VoiceOption;
  sassLevel: 'subtle' | 'playful' | 'unhinged';
  autoOpenTabs: boolean;
  hapticFeedback: boolean;
  soundEffects: boolean;
}

export interface ToolCallEvent {
  id: string;
  name: string;
  args: Record<string, unknown>;
  timestamp: number;
}

export interface VikAiAction {
  type: 'website' | 'vibe' | 'effect' | 'info';
  title: string;
  description: string;
  icon?: string;
  data?: Record<string, unknown>;
}

export interface TranscriptSnippet {
  id: string;
  speaker: 'user' | 'vikai';
  text: string;
  timestamp: number;
}
