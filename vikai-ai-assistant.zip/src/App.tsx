import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Sliders,
  Radio,
  Wifi,
  WifiOff,
  AlertCircle,
  HelpCircle,
  Flame,
  Volume2,
  ExternalLink,
  Lock,
} from 'lucide-react';
import { useVikAiLive } from './hooks/useVikAiLive';
import { VikAiLedAvatar } from './components/VikAiLedAvatar';
import { AudioWaveform } from './components/AudioWaveform';
import { SassyQuickPrompts } from './components/SassyQuickPrompts';
import { LiveSubtitles } from './components/LiveSubtitles';
import { ActionNotification } from './components/ActionNotification';
import { PersonalitySettingsModal } from './components/PersonalitySettingsModal';
import { MediaActionsMenu } from './components/MediaActionsMenu';
import { FloatingScreenShareBar } from './components/FloatingScreenShareBar';
import { LockScreen } from './components/LockScreen';
import { useScreenShare } from './hooks/useScreenShare';
import { VIBE_THEMES } from './constants/vibes';
import { VibeTheme, PersonalityConfig } from './types/vikai';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('vikai_auth_session') === 'true';
    } catch {
      return false;
    }
  });

  const [currentVibe, setVibe] = useState<VibeTheme>('cyber-cyan');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [isMediaMenuOpen, setIsMediaMenuOpen] = useState(false);

  const [personality, setPersonality] = useState<PersonalityConfig>({
    voice: 'Aoede',
    sassLevel: 'playful',
    autoOpenTabs: true,
    hapticFeedback: true,
    soundEffects: true,
  });

  const vibeConfig = VIBE_THEMES[currentVibe] || VIBE_THEMES['neon-violet'];

  const {
    state,
    micVolume,
    speakerVolume,
    liveSubtitle,
    hasMicPermission,
    isSpeakerOnlyMode,
    recentAction,
    lastInterrupted,
    errorMessage,
    streamer,
    connect,
    disconnect,
    sendPromptTrigger,
    sendImageFrame,
    clearRecentAction,
    clearError,
  } = useVikAiLive(currentVibe, setVibe, personality);

  const [screenShareNotification, setScreenShareNotification] = useState<string | null>(null);

  const {
    isScreenSharing,
    error: screenShareError,
    statusMessage: screenShareStatus,
    startScreenShare,
    stopScreenShare,
    clearError: clearScreenShareError,
  } = useScreenShare({
    onFrame: (base64Jpeg) => {
      sendImageFrame(base64Jpeg);
    },
    onShareStarted: () => {
      setScreenShareNotification('Screen sharing active — VikAI is watching');
      if (state === 'disconnected') {
        connect();
      }
    },
    onShareEnded: () => {
      setScreenShareNotification('Screen sharing stopped.');
      setTimeout(() => setScreenShareNotification(null), 3500);
    },
  });

  const handleToggleScreenShare = async () => {
    if (isScreenSharing) {
      stopScreenShare();
    } else {
      await startScreenShare();
    }
  };

  const handleOrbToggle = () => {
    if (state === 'disconnected') {
      connect();
    } else {
      disconnect();
    }
  };

  const handleUnlock = () => {
    setIsAuthenticated(true);
    try {
      sessionStorage.setItem('vikai_auth_session', 'true');
    } catch {
      // ignore
    }
  };

  const handleLockApp = () => {
    if (isScreenSharing) {
      stopScreenShare();
    }
    disconnect();
    setIsAuthenticated(false);
    setIsSettingsOpen(false);
    setIsMediaMenuOpen(false);
    try {
      sessionStorage.removeItem('vikai_auth_session');
    } catch {
      // ignore
    }
  };

  const handleOpenInNewTab = () => {
    try {
      window.open(window.location.href, '_blank');
    } catch {
      // ignore
    }
  };

  const isConnected = state !== 'disconnected';

  // If not authenticated, show the full-screen Lock Screen
  if (!isAuthenticated) {
    return <LockScreen onUnlock={handleUnlock} vibe={vibeConfig} />;
  }

  return (
    <div
      id="vikai-app-root"
      className={`min-h-screen w-full bg-gradient-to-b ${vibeConfig.bgGradient} text-white flex flex-col justify-between overflow-x-hidden font-sans relative select-none transition-colors duration-700`}
    >
      {/* Background ambient radial glow overlays */}
      <div
        className="fixed top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[34rem] h-[34rem] rounded-full blur-[120px] pointer-events-none opacity-30 transition-all duration-700"
        style={{ background: vibeConfig.primary }}
      />
      <div
        className="fixed bottom-10 right-10 w-80 h-80 rounded-full blur-[100px] pointer-events-none opacity-20 transition-all duration-700"
        style={{ background: vibeConfig.accent }}
      />

      {/* Floating Screen Share Assistant Mode Overlay */}
      <FloatingScreenShareBar
        isSharing={isScreenSharing}
        onStop={stopScreenShare}
        vibe={vibeConfig}
      />

      {/* Action Notification Pop-in */}
      <ActionNotification
        action={recentAction}
        vibe={vibeConfig}
        onDismiss={clearRecentAction}
      />

      {/* Screen Share Status Banner */}
      {screenShareNotification && !isScreenSharing && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-40 px-4 py-2 rounded-full bg-cyan-950/90 border border-cyan-500/40 text-xs font-semibold text-cyan-200 shadow-xl backdrop-blur-md animate-fade-in">
          {screenShareNotification}
        </div>
      )}

      {/* Error Alert */}
      {(errorMessage || screenShareError) && (
        <div className="relative z-20 w-full max-w-md mx-auto px-4 mb-2">
          <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-xs text-rose-200 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage || screenShareError}</span>
            </div>
            <button
              onClick={() => {
                if (errorMessage) clearError();
                if (screenShareError) clearScreenShareError();
              }}
              className="text-rose-300 hover:text-white font-bold ml-2 cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      )}
      <header id="vikai-header" className="relative z-30 w-full max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
        {/* Left: Branding & Status */}
        <div className="flex items-center space-x-3">
          <div
            className="w-10 h-10 rounded-2xl flex items-center justify-center shadow-lg transition-transform hover:scale-105"
            style={{
              background: `linear-gradient(135deg, ${vibeConfig.primary}, ${vibeConfig.accent})`,
              boxShadow: `0 0 20px ${vibeConfig.glow}`,
            }}
          >
            <Sparkles className="w-5 h-5 text-white" />
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-black tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-neutral-100 to-neutral-300">
                VikAi
              </h1>
              <span
                className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-widest text-white shadow-sm"
                style={{ background: vibeConfig.primary }}
              >
                AI
              </span>
            </div>
            <p className="text-[11px] text-neutral-400 font-medium flex items-center gap-1">
              <Flame className="w-3 h-3 text-cyan-400" />
              Holographic LED Voice Assistant
            </p>
          </div>
        </div>

        {/* Right: Controls & Connection Indicator */}
        <div className="flex items-center space-x-2">
          {/* Connection Status Pill */}
          <div className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-neutral-300">
            {isConnected ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                <span>Live Audio</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5 text-neutral-500" />
                <span>Standby</span>
              </>
            )}
          </div>

          {/* Open in new tab button */}
          <button
            onClick={handleOpenInNewTab}
            className="hidden sm:flex items-center space-x-1 p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white transition-colors cursor-pointer text-xs"
            title="Open app in full tab for clearest mic capture"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span className="hidden md:inline text-[11px] font-medium">New Tab</span>
          </button>

          {/* Help / Info Toggle */}
          <button
            onClick={() => setShowInfo(!showInfo)}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white transition-colors cursor-pointer"
            title="About VikAi & Features"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {/* Settings Button */}
          <button
            id="settings-trigger-button"
            onClick={() => setIsSettingsOpen(true)}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white transition-colors cursor-pointer"
            title="Settings & Persona"
          >
            <Sliders className="w-4 h-4" />
          </button>

          {/* Quick Lock Button */}
          <button
            id="header-quick-lock-button"
            onClick={handleLockApp}
            className="p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 border border-white/10 hover:border-rose-500/40 text-neutral-300 hover:text-rose-300 transition-colors cursor-pointer"
            title="Lock VikAI session"
          >
            <Lock className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Info drawer / banner if toggled */}
      {showInfo && (
        <div className="relative z-20 w-full max-w-xl mx-auto px-4 mb-2">
          <div className="p-3.5 rounded-2xl bg-white/10 border border-white/15 backdrop-blur-xl text-xs space-y-1.5 text-neutral-200">
            <div className="flex items-center justify-between font-bold text-white">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-pink-400" /> How to interact with VikAi
              </span>
              <button onClick={() => setShowInfo(false)} className="text-neutral-400 hover:text-white">✕</button>
            </div>
            <p>
              • <strong>Voice-to-Voice:</strong> Tap the central glowing orb to start the low-latency Gemini Live session. Speak directly into your mic.
            </p>
            {isSpeakerOnlyMode && (
              <p className="text-amber-300">• <strong>Speaker Mode:</strong> Microphone is currently inactive. You can tap any quick prompt below to hear VikAi respond with live audio speech.</p>
            )}
            <p>
              • <strong>Personality:</strong> VikAi responds with sharp wit, confident banter, casual Hindi/English blend, and playful teasing.
            </p>
            <p>
              • <strong>Tool Execution:</strong> Say <em>"Open YouTube"</em>, <em>"Open Spotify"</em>, or <em>"Shift vibe to Cyber Cyan"</em> to trigger dynamic browser actions!
            </p>
          </div>
        </div>
      )}

      {/* Main Interactive Stage */}
      <main id="vikai-main-stage" className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 py-2 text-center max-w-2xl mx-auto w-full">
        {/* Real-time Subtitles / Dialogue Caption Bubble */}
        <LiveSubtitles subtitle={liveSubtitle} state={state} vibe={vibeConfig} />

        {/* Central Futuristic Living LED Face Avatar */}
        <div className="my-1">
          <VikAiLedAvatar
            state={state}
            vibe={vibeConfig}
            micVolume={micVolume}
            speakerVolume={speakerVolume}
            isInterrupted={lastInterrupted}
            onToggle={handleOrbToggle}
          />
        </div>

        {/* Audio Waveform Canvas */}
        <AudioWaveform streamer={streamer} state={state} vibe={vibeConfig} />

        {/* Quick Banter & Tool Prompts */}
        <div className="w-full mt-2">
          <SassyQuickPrompts
            vibe={vibeConfig}
            onSelectPrompt={sendPromptTrigger}
            disabled={state === 'connecting'}
          />
        </div>

        {/* Floating Multimodal Media Actions Button & Glassmorphic Menu */}
        <div className="mt-3">
          <MediaActionsMenu
            isOpen={isMediaMenuOpen}
            onToggle={() => setIsMediaMenuOpen(!isMediaMenuOpen)}
            vibe={vibeConfig}
            isScreenSharing={isScreenSharing}
            onToggleScreenShare={handleToggleScreenShare}
          />
        </div>
      </main>

      {/* Footer Controls */}
      <footer id="vikai-footer" className="relative z-20 w-full max-w-lg mx-auto px-4 py-3 text-center">
        <div className="flex items-center justify-center space-x-3 text-[11px] text-neutral-400">
          <span className="flex items-center gap-1">
            <Radio className="w-3 h-3 text-purple-400" />
            PCM16 16kHz Streaming
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Volume2 className="w-3 h-3 text-pink-400" />
            24kHz Web Audio
          </span>
          <span>•</span>
          <span className="text-neutral-500">Gemini Live API</span>
        </div>
      </footer>

      {/* Settings Modal */}
      <PersonalitySettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        personality={personality}
        setPersonality={setPersonality}
        currentVibe={currentVibe}
        setVibe={setVibe}
        vibeConfig={vibeConfig}
        onLockApp={handleLockApp}
      />
    </div>
  );
}
