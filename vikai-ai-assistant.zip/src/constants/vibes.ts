import { VibeConfig, VibeTheme } from '../types/vikai';

export const VIBE_THEMES: Record<VibeTheme, VibeConfig> = {
  'neon-violet': {
    id: 'neon-violet',
    name: 'Neon Violet',
    primary: '#A855F7',
    glow: 'rgba(168, 85, 247, 0.45)',
    bgGradient: 'from-slate-950 via-[#0d071a] to-zinc-950',
    orbGradient: 'from-purple-500 via-fuchsia-500 to-pink-500',
    accent: '#EC4899',
  },
  'cyber-cyan': {
    id: 'cyber-cyan',
    name: 'Cyber Cyan',
    primary: '#06B6D4',
    glow: 'rgba(6, 182, 212, 0.45)',
    bgGradient: 'from-slate-950 via-[#031525] to-zinc-950',
    orbGradient: 'from-cyan-400 via-teal-400 to-blue-500',
    accent: '#3B82F6',
  },
  'electric-magenta': {
    id: 'electric-magenta',
    name: 'Electric Magenta',
    primary: '#F43F5E',
    glow: 'rgba(244, 63, 94, 0.45)',
    bgGradient: 'from-slate-950 via-[#1c0812] to-zinc-950',
    orbGradient: 'from-rose-500 via-pink-500 to-purple-600',
    accent: '#D946EF',
  },
  'sunset-amber': {
    id: 'sunset-amber',
    name: 'Sunset Amber',
    primary: '#F59E0B',
    glow: 'rgba(245, 158, 11, 0.45)',
    bgGradient: 'from-slate-950 via-[#1a0f05] to-zinc-950',
    orbGradient: 'from-amber-400 via-orange-500 to-rose-500',
    accent: '#EF4444',
  },
  'emerald-matrix': {
    id: 'emerald-matrix',
    name: 'Emerald Matrix',
    primary: '#10B981',
    glow: 'rgba(16, 185, 129, 0.45)',
    bgGradient: 'from-slate-950 via-[#051a11] to-zinc-950',
    orbGradient: 'from-emerald-400 via-teal-500 to-lime-400',
    accent: '#84CC16',
  },
};
