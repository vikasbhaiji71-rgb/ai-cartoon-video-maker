/**
 * AudioStreamer manages high-performance, low-latency audio capture and playback for Gemini Live API.
 * - Input: 16kHz 16-bit Mono PCM streaming to WebSocket
 * - Output: 24kHz 16-bit Mono PCM gapless playback from WebSocket
 */

// Helper to convert base64 to Uint8Array
function base64ToUint8Array(base64: string): Uint8Array {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Helper to convert Float32Array to 16-bit PCM base64 string
function float32ToPcm16Base64(float32Array: Float32Array): string {
  const buffer = new ArrayBuffer(float32Array.length * 2);
  const view = new DataView(buffer);
  let offset = 0;
  for (let i = 0; i < float32Array.length; i++, offset += 2) {
    const s = Math.max(-1, Math.min(1, float32Array[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunkSize)));
  }
  return window.btoa(binary);
}

// Linear downsampler from input sampleRate to 16000Hz
function downsampleBuffer(buffer: Float32Array, inputRate: number, outputRate: number = 16000): Float32Array {
  if (inputRate === outputRate) return buffer;
  const ratio = inputRate / outputRate;
  const newLength = Math.round(buffer.length / ratio);
  const result = new Float32Array(newLength);
  let offsetResult = 0;
  let offsetBuffer = 0;
  while (offsetResult < result.length) {
    const nextOffsetBuffer = Math.round((offsetResult + 1) * ratio);
    let accum = 0;
    let count = 0;
    for (let i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
      accum += buffer[i];
      count++;
    }
    result[offsetResult] = count > 0 ? accum / count : buffer[Math.floor(offsetBuffer)];
    offsetResult++;
    offsetBuffer = nextOffsetBuffer;
  }
  return result;
}

export class AudioStreamer {
  private inputAudioCtx: AudioContext | null = null;
  private outputAudioCtx: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private inputSource: MediaStreamAudioSourceNode | null = null;
  
  private inputAnalyser: AnalyserNode | null = null;
  private outputAnalyser: AnalyserNode | null = null;
  private outputGainNode: GainNode | null = null;

  private nextPlayTime: number = 0;
  private activeSources: Set<AudioBufferSourceNode> = new Set();
  
  public onAudioData: ((base64Pcm16: string) => void) | null = null;
  public onSpeakingStateChange: ((isSpeaking: boolean) => void) | null = null;

  private isSpeaking: boolean = false;
  private speakingCheckTimer: number | null = null;

  /**
   * Initializes microphone capture and output audio contexts
   * @param allowSpeakerOnly if true, won't fail if mic is blocked or denied, allowing speaker mode
   */
  async startRecording(allowSpeakerOnly: boolean = false): Promise<{ hasMic: boolean }> {
    // 1. Setup Input Context (16kHz preferred or downsampled)
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    
    let hasMic = false;
    if (navigator?.mediaDevices?.getUserMedia) {
      try {
        this.mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
        hasMic = true;
      } catch (err: any) {
        console.warn('[AudioStreamer] Microphone access not granted:', err);
        if (!allowSpeakerOnly) {
          throw err;
        }
      }
    } else if (!allowSpeakerOnly) {
      throw new Error('Microphone access is not supported in this browser context.');
    }

    if (hasMic && this.mediaStream) {
      this.inputAudioCtx = new AudioContextClass();
      if (this.inputAudioCtx.state === 'suspended') {
        await this.inputAudioCtx.resume();
      }

      this.inputSource = this.inputAudioCtx.createMediaStreamSource(this.mediaStream);
      this.inputAnalyser = this.inputAudioCtx.createAnalyser();
      this.inputAnalyser.fftSize = 256;
      this.inputAnalyser.smoothingTimeConstant = 0.5;

      // Buffer size 4096 gives ~0.08s chunks at 48kHz or ~0.25s at 16kHz
      this.scriptProcessor = this.inputAudioCtx.createScriptProcessor(4096, 1, 1);

      const actualSampleRate = this.inputAudioCtx.sampleRate;

      this.scriptProcessor.onaudioprocess = (e: AudioProcessingEvent) => {
        if (!this.onAudioData) return;
        const inputData = e.inputBuffer.getChannelData(0);
        
        // Resample to 16kHz if necessary
        const resampled = downsampleBuffer(inputData, actualSampleRate, 16000);
        const base64Pcm = float32ToPcm16Base64(resampled);
        this.onAudioData(base64Pcm);
      };

      this.inputSource.connect(this.inputAnalyser);
      this.inputAnalyser.connect(this.scriptProcessor);
      this.scriptProcessor.connect(this.inputAudioCtx.destination);
    }

    // 2. Setup Output Context (24000Hz for Gemini Live output)
    if (!this.outputAudioCtx) {
      try {
        this.outputAudioCtx = new AudioContextClass({ sampleRate: 24000 });
      } catch {
        this.outputAudioCtx = new AudioContextClass();
      }
      
      this.outputAnalyser = this.outputAudioCtx.createAnalyser();
      this.outputAnalyser.fftSize = 256;
      this.outputAnalyser.smoothingTimeConstant = 0.6;
      
      this.outputGainNode = this.outputAudioCtx.createGain();
      this.outputGainNode.gain.value = 1.0;
      
      this.outputGainNode.connect(this.outputAnalyser);
      this.outputAnalyser.connect(this.outputAudioCtx.destination);
    }

    if (this.outputAudioCtx.state === 'suspended') {
      await this.outputAudioCtx.resume();
    }

    this.nextPlayTime = this.outputAudioCtx.currentTime;
    return { hasMic };
  }

  /**
   * Enqueue 24kHz PCM 16-bit audio chunk received from Gemini Live
   */
  async enqueuePcmAudio(base64Pcm: string): Promise<void> {
    if (!this.outputAudioCtx || !this.outputGainNode) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      try {
        this.outputAudioCtx = new AudioContextClass({ sampleRate: 24000 });
      } catch {
        this.outputAudioCtx = new AudioContextClass();
      }
      this.outputAnalyser = this.outputAudioCtx.createAnalyser();
      this.outputAnalyser.fftSize = 256;
      this.outputAnalyser.smoothingTimeConstant = 0.6;
      this.outputGainNode = this.outputAudioCtx.createGain();
      this.outputGainNode.gain.value = 1.0;
      this.outputGainNode.connect(this.outputAnalyser);
      this.outputAnalyser.connect(this.outputAudioCtx.destination);
    }

    if (this.outputAudioCtx.state === 'suspended') {
      await this.outputAudioCtx.resume();
    }

    const uint8 = base64ToUint8Array(base64Pcm);
    const int16 = new Int16Array(uint8.buffer, uint8.byteOffset, uint8.byteLength / 2);
    
    const float32 = new Float32Array(int16.length);
    for (let i = 0; i < int16.length; i++) {
      float32[i] = int16[i] / 32768.0;
    }

    const audioBuffer = this.outputAudioCtx.createBuffer(1, float32.length, 24000);
    audioBuffer.copyToChannel(float32, 0);

    const source = this.outputAudioCtx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(this.outputGainNode);

    const currentTime = this.outputAudioCtx.currentTime;
    const startTime = Math.max(currentTime, this.nextPlayTime);
    source.start(startTime);
    this.nextPlayTime = startTime + audioBuffer.duration;

    this.activeSources.add(source);
    this.setSpeakingState(true);

    source.onended = () => {
      this.activeSources.delete(source);
      this.checkSpeakingEnd();
    };
  }

  /**
   * Immediately stops playback when Mahi is interrupted
   */
  interrupt(): void {
    for (const source of this.activeSources) {
      try {
        source.stop();
        source.disconnect();
      } catch {
        // Source might have already finished
      }
    }
    this.activeSources.clear();
    if (this.outputAudioCtx) {
      this.nextPlayTime = this.outputAudioCtx.currentTime;
    }
    this.setSpeakingState(false);
  }

  private checkSpeakingEnd(): void {
    if (this.speakingCheckTimer) {
      window.clearTimeout(this.speakingCheckTimer);
    }
    this.speakingCheckTimer = window.setTimeout(() => {
      if (this.activeSources.size === 0) {
        if (!this.outputAudioCtx || this.outputAudioCtx.currentTime >= this.nextPlayTime - 0.05) {
          this.setSpeakingState(false);
        }
      }
    }, 80);
  }

  private setSpeakingState(speaking: boolean): void {
    if (this.isSpeaking !== speaking) {
      this.isSpeaking = speaking;
      if (this.onSpeakingStateChange) {
        this.onSpeakingStateChange(speaking);
      }
    }
  }

  /**
   * Get current microphone input volume level [0.0 - 1.0]
   */
  getInputVolume(): number {
    if (!this.inputAnalyser) return 0;
    const dataArray = new Uint8Array(this.inputAnalyser.frequencyBinCount);
    this.inputAnalyser.getByteFrequencyData(dataArray);
    let sum = 0;
    for (let i = 0; i < dataArray.length; i++) {
      sum += dataArray[i];
    }
    const avg = sum / dataArray.length;
    return Math.min(1, avg / 128);
  }

  /**
   * Get current AI output voice volume level [0.0 - 1.0]
   */
  getOutputVolume(): number {
    if (!this.outputAnalyser || !this.isSpeaking) return 0;
    const dataArray = new Uint8Array(this.outputAnalyser.frequencyBinCount);
    this.outputAnalyser.getByteFrequencyData(dataArray);
    let sum = 0;
    for (let i = 0; i < dataArray.length; i++) {
      sum += dataArray[i];
    }
    const avg = sum / dataArray.length;
    return Math.min(1, avg / 128);
  }

  /**
   * Get frequency data array for visualizer waveform
   */
  getFrequencyData(forOutput: boolean): Uint8Array {
    const analyser = forOutput ? this.outputAnalyser : this.inputAnalyser;
    if (!analyser) return new Uint8Array(64);
    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    analyser.getByteFrequencyData(dataArray);
    return dataArray;
  }

  /**
   * Stop everything and release hardware microphone
   */
  stop(): void {
    this.interrupt();

    if (this.scriptProcessor) {
      this.scriptProcessor.disconnect();
      this.scriptProcessor = null;
    }
    if (this.inputSource) {
      this.inputSource.disconnect();
      this.inputSource = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }
    if (this.inputAudioCtx && this.inputAudioCtx.state !== 'closed') {
      this.inputAudioCtx.close();
      this.inputAudioCtx = null;
    }
    if (this.outputAudioCtx && this.outputAudioCtx.state !== 'closed') {
      this.outputAudioCtx.close();
      this.outputAudioCtx = null;
    }
    this.setSpeakingState(false);
  }
}
